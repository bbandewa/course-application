package de.smava.recrt.jms;

public class Constants {

    public static final String TOPIC_DEFAULT = "default.topic";
    public static final String QUEUE_BANK_ACCOUNT_CREATE = "bank.account.create";
}
