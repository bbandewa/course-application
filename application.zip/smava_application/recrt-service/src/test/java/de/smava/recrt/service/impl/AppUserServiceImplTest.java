package de.smava.recrt.service.impl;

import org.junit.Test;

public class AppUserServiceImplTest {

    @Test
    public void testGetAll() throws Exception {

    }

    @Test
    public void testGet() throws Exception {

    }
}