package de.smava.recrt.rest;

import org.junit.Test;

public class AppUserApiTest {

    @Test
    public void testSearch() throws Exception {

    }
}