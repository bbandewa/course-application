package de.smava.recrt.persistence.repository;

import org.junit.Test;

public class AppUserRepositoryTest {

    @Test
    public void testSave() throws Exception {

    }

    @Test
    public void testFindOne() throws Exception {

    }

    @Test
    public void testDelete() throws Exception {

    }

}