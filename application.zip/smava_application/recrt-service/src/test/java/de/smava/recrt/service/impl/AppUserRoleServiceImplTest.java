package de.smava.recrt.service.impl;

import org.junit.Test;

public class AppUserRoleServiceImplTest {

    @Test
    public void testGetByAppUser() throws Exception {

    }
}