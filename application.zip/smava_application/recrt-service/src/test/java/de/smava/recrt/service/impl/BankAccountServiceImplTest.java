package de.smava.recrt.service.impl;

import org.junit.Test;

public class BankAccountServiceImplTest {

    @Test
    public void testGetByAppUser() throws Exception {

    }

    @Test
    public void testCreate() throws Exception {

    }
}