package de.smava.recrt.persistence.repository;

import org.junit.Test;

public class AppUserRoleRepositoryTest {

    @Test
    public void testFindByKeyAppUser() throws Exception {

    }
}