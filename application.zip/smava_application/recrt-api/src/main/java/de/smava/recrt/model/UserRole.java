package de.smava.recrt.model;

public enum UserRole {
    ROLE_USER, ROLE_ADMIN
}
