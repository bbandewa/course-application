package de.smava.recrt.model;

public interface AppUserRole {

    UserRole getRole();

    void setRole(UserRole role);

}
