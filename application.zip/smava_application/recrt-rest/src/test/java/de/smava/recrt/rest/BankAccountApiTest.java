package de.smava.recrt.rest;

import org.junit.Test;

public class BankAccountApiTest {

    @Test
    public void testGetAll() throws Exception {

    }

    @Test
    public void testCreate() throws Exception {

    }
}